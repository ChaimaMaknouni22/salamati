import QRCode from "qrcode";
import fs from "fs";

const LOCAL_IP = "10.252.130.130"; // ← mets ton IP (trouvée avec ipconfig)
const PORT = 3000;

const code = process.argv[2] || "SITE-001";
const url = `http://${LOCAL_IP}:${PORT}/?site=${code}`;
const filename = `qrcode_${code}.png`;

QRCode.toFile(filename, url, { width: 400 }, err=>{
  if(err) return console.error(err);
  console.log("QR généré:", filename, "URL:", url);
});
