// server.js - WAWW PRO en ESM
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const DB = path.join(__dirname, 'data.json');
let db = { signals: [], points: {} };

if (fs.existsSync(DB)) {
  try {
    db = JSON.parse(fs.readFileSync(DB));
  } catch (e) {
    console.error(e);
  }
}

function save() {
  fs.writeFileSync(DB, JSON.stringify(db, null, 2));
}

app.post('/signalement', (req, res) => {
  const { name, category, subtype, comment, before, after } = req.body;
  if (!name || !category || !subtype) {
    return res.status(400).json({ error: 'missing' });
  }

  const item = {
    id: Date.now().toString(36),
    name,
    category,
    subtype,
    comment: comment || '',
    before: before || null,
    after: after || null,
    date: new Date().toISOString(),
  };

  db.signals.unshift(item);
  db.points[name] = (db.points[name] || 0) + 5; // 5 points par participation
  if (db.signals.length > 2000) db.signals = db.signals.slice(0, 2000);
  save();
  res.json({ ok: true, points: db.points[name] });
});

app.get('/api/getAll', (req, res) => res.json(db));

app.post('/api/reset', (req, res) => {
  db = { signals: [], points: {} };
  save();
  res.json({ ok: true });
});

app.listen(PORT, () =>
  console.log(`🚀 WAWW PRO listening on http://localhost:${PORT}`)
);
